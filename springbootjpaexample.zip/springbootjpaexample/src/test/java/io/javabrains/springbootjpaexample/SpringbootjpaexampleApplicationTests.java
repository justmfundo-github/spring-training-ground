package io.javabrains.springbootjpaexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootjpaexampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
